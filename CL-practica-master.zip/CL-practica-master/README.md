# CL-practica

Practica de Compiladores con ANTLR4

## TODO: 

salu2.asl si hacemos 1/2 en el float que elevamos peta. si hacemos 1.0/2 bien
