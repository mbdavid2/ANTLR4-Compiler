# CL-practica

Practica de Compiladores con ANTLR4

## TODO: 

-  TyupeCheck de la funcion y de lo que queda de las expresiones :D


