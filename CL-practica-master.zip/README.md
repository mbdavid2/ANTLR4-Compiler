# CL-practica

Practica de Compiladores con ANTLR4

## TODO: 

-  ver si es int/char/float en:
  - write
  - assign
  - etc
  
  ditinguir floats en todos lados


