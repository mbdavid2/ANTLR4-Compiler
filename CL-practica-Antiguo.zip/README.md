# CL-practica

Practica de Compiladores con ANTLR4

## TODO: 

- 	Preguntarle al profe sobre array access: 
	Hay que hacer las comprobaciones en el arrayaccess o en la expression (pq puede ser left_expr o expr normal)

-	El arrayAccess comprueva bien las cosas, pero si es correcto qué hay que ponerle? Eso de putDecorNoseque


